Please open the index.html where in Documentation folder with your browser to read the help file.


DO NOT UPLOAD ENTIRE PACKAGE 
----------------------------
Do not upload the entire file you get from this package, upload only the rttheme19.zip (if you will use WordPress theme upload tool). Please read "A) Installation" section of the Documentation for further details. 