<?php
#-----------------------------------------
#	RT-Theme vc_functions.php
#-----------------------------------------

if ( class_exists( 'WPBakeryVisualComposer' ) ){


/*

	#
	#	Widget Titles
	#	
	function rt_wpb_widget_title($output = '', $params = array('')) {

		$extraclass = (isset($params['extraclass'])) ? " ".$params['extraclass'] : "";
		$output = '<h4 class="wpb_heading'.$extraclass.'">' . $params['title'] . '</h4>';

		return '<h4 class="wpb_heading'.$extraclass.'">' . $params['title'] . '</h4>';
	}
	add_filter('wpb_widget_title','rt_wpb_widget_title', 10, 2);

*/

 
}
?>